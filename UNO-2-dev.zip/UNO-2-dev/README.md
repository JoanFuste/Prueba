Proyecto del grupo 3 de Sistemas Operativos (2023-24-Q2)
UNO

Version 1

generada por Emmanuel Alonso Mendoza Cobeña
verificada por Pol Miró
comunicada por Joan Fusté
URL: https://www.youtube.com/watch?v=ju_lTH3MJwU

Version 2

generada por Pol Miró


Pendiente (Requisitos a implementar en esta versión)

-Implementar interfaz gráfica (añadir cartas del cliente)

-Lista conectados

Avances (Requisitos del proyecto):

-

Mejoras (Arreglo de bugs, mejoras estéticas...):

-Cambio base de datos

-Encriptación de Password desde cliente

-Arreglo crasheo de cliente cuando pulsas Send si no te conectas

Errores detectados:

-


